/**
 * Store для управления остатками материалов
 */
import { ref } from 'vue'
import api from '@/api/client'
import { endpoints } from '@/api/endpoints'
import { createBaseStore } from './base'
import type { MaterialBalance, ObjectBalance } from '@/api/types/stocks'

// Создаём базовый store
export const useBalancesStore = createBaseStore<ObjectBalance & { id: number }, any, any>({
  endpoint: {
    list: endpoints.stockSnapshots.byObjects,
    one: (id: number) => `${endpoints.stockSnapshots.byObjects}${id}/`
  },
  entityName: 'balances',
  entityNamePlural: 'остатки',
  defaultOrdering: 'object_name'
})

// Расширенные фильтры для остатков
const extendedFilters = ref({
  search: '',
  object: '',
  date: new Date().toISOString().split('T')[0]
})

// ============================================================================
// Custom Actions
// ============================================================================

export const fetchBalancesList = async (params?: {
  page?: number
  search?: string
  object?: string
  date?: string
}) => {
  const store = useBalancesStore()
  store.loading = true
  store.error = null

  try {
    const apiParams = new URLSearchParams()
    if (extendedFilters.value.object) {
      apiParams.append('object_id', extendedFilters.value.object)
    }
    if (extendedFilters.value.date) {
      apiParams.append('date', extendedFilters.value.date)
    }

    const response = await api.get(`${endpoints.stockSnapshots.byObjects}?${apiParams}`)
    
    const objectsData: (ObjectBalance & { id: number })[] = []
    if (response.data.objects) {
      response.data.objects.forEach((obj: any) => {
        objectsData.push({
          id: obj.object_id,
          object_id: obj.object_id,
          object_name: obj.object_name,
          object_address: obj.object_address,
          materials: obj.materials.map((material: any) => ({
            material_id: material.material_id,
            material_name: material.material_name,
            unit_code: material.unit_code,
            current_balance: material.current_balance,
            total_purchased: material.total_purchased,
            total_written_off: material.total_written_off
          } as MaterialBalance)),
          total_materials: obj.materials.length
        })
      })
    }
    
    store.items = objectsData
    store.pagination.count = objectsData.length
    store.pagination.page = 1
    store.pagination.next = null
    store.pagination.previous = null

    if (params) {
      Object.assign(extendedFilters.value, params)
    }
  } catch (error: any) {
    store.error = 'Ошибка загрузки остатков'
    throw error
  } finally {
    store.loading = false
  }
}

export const setBalancesFilters = async (newFilters: any) => {
  const store = useBalancesStore()
  Object.assign(extendedFilters.value, newFilters)
  store.filters = {
    ...extendedFilters.value,
    ordering: store.filters?.ordering || 'object_name'
  }
  store.pagination.page = 1
  await fetchBalancesList()
}

export const resetBalancesFilters = async () => {
  const store = useBalancesStore()
  Object.assign(extendedFilters.value, {
    search: '',
    object: '',
    date: new Date().toISOString().split('T')[0]
  })
  store.filters = {
    ...extendedFilters.value,
    ordering: store.filters?.ordering || 'object_name'
  }
  store.pagination.page = 1
  await fetchBalancesList()
}

// ============================================================================
// Helper Functions
// ============================================================================

export const getBalancesFilters = () => {
  return extendedFilters
}
